export const URL = 'http://localhost:3030'
//const URL = 'http://44.206.218.5:3030'
// const URL = 'https://zoodex.site'
